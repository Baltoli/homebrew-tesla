#include "Debug.h"
#include "Manifest.h"
#include "tesla.pb.h"

#include "model-checker/Z3Pass.h"
#include "mutex/AcquireReleasePass.h"

#include <google/protobuf/text_format.h>

#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>
#include <llvm/IRReader/IRReader.h>
#include <llvm/Support/CommandLine.h>
#include <llvm/Support/FileSystem.h>
#include <llvm/Support/ManagedStatic.h>
#include <llvm/Support/PrettyStackTrace.h>
#include <llvm/Support/raw_ostream.h>
#include <llvm/Support/SourceMgr.h>

using namespace llvm;
using std::string;

// Command Line Options

static cl::opt<std::string>
ManifestFilename(cl::Positional, cl::desc("manifest"), cl::Required);

static cl::opt<std::string>
BitcodeFilename(cl::Positional, cl::desc("bitcode"), cl::Required);

static cl::OptionCategory PassCat("Pass selection flags",
                                  "These flags control which manifest passes are run");

static cl::opt<bool>
EnableAcqRelPass("acqrel", cl::desc("Run hand-coded acquire-release pass"),
                 cl::init(false), cl::cat(PassCat));

static cl::opt<bool>
EnableZ3Checker("mc", cl::desc("Run the model checker"),
                cl::init(false), cl::cat(PassCat));

static cl::OptionCategory ModelCat("Model checker options",
                                   "These flags control the model checker if it is run");

static cl::opt<int>
UnrollDepth("unroll", cl::desc("Event graph recursion depth (default=32)"),
            cl::init(32), cl::cat(ModelCat));

static cl::opt<int>
TraceBound("bound", cl::desc("Finite model checking bound (default=50)"),
            cl::init(50), cl::cat(ModelCat));

static cl::opt<std::string>
OutputFilename("o", cl::desc("Specify output filename"), 
               cl::value_desc("filename"), cl::init("-"));

static LLVMContext Context;

int main(int argc, char **argv) {
  PrettyStackTraceProgram X(argc, argv);
  llvm_shutdown_obj Y;

  cl::ParseCommandLineOptions(argc, argv, "TESLA Static Analyser\n");

  SMDiagnostic Err;
  
  // Load manifest and bitcode from disk
  std::unique_ptr<tesla::Manifest> Manifest(tesla::Manifest::load(
    llvm::errs(), tesla::Automaton::Deterministic, ManifestFilename));
  if(!Manifest) {
    tesla::panic("unable to load TESLA manifest");
  }

  std::unique_ptr<Module> Mod(parseIRFile(BitcodeFilename, Err, Context));
  if(Mod.get() == nullptr) {
    Err.print(argv[0], errs());
    return 1;
  }

  // Run analysis passes
  tesla::ManifestPassManager PM(std::move(Manifest), std::move(Mod));
  if(EnableAcqRelPass) PM.addPass(new tesla::AcquireReleasePass);
  if(EnableZ3Checker) PM.addPass(new tesla::Z3Pass(UnrollDepth, TraceBound));

  PM.runPasses();
  if(!PM.successful()) {
    tesla::panic("Error applying manifest passes");
  }

  // Dump new manifest file
  std::string ProtobufText;
  google::protobuf::TextFormat::PrintToString(PM.getResult().getProtobuf(), &ProtobufText);

  std::unique_ptr<raw_fd_ostream> outfile;
  if(OutputFilename != "-") {
    std::error_code OutErrorInfo;
    outfile.reset(new raw_fd_ostream(OutputFilename.c_str(), OutErrorInfo, llvm::sys::fs::F_RW));
  }
  raw_ostream& out = (OutputFilename == "-") ? llvm::outs() : *outfile;
  out << ProtobufText;

  google::protobuf::ShutdownProtobufLibrary();

  return 0;
}
